#!/bin/bash
set -e

LAUNCH_DIR=`pwd`
echo "Job Launched in directory $LAUNCH_DIR"
source $DECAF_ENV_SOURCE


# copy the json file for the job into the directory
# where we are going to launch decaf
cp 1Kgenome.json $PEGASUS_SCRATCH_DIR/

cd $PEGASUS_SCRATCH_DIR
echo "Invoking decaf executable from directory `pwd`"
cat <<EOF > merge_cluster1.conf
0 ./individuals ALL.chr1.250000.vcf 1 1 15626 250000
1 ./individuals ALL.chr1.250000.vcf 1 171876 187501 250000
2 ./individuals ALL.chr1.250000.vcf 1 15626 31251 250000
3 ./individuals ALL.chr1.250000.vcf 1 187501 203126 250000
4 ./individuals ALL.chr1.250000.vcf 1 140626 156251 250000
5 ./individuals ALL.chr1.250000.vcf 1 156251 171876 250000
6 ./individuals ALL.chr1.250000.vcf 1 62501 78126 250000
7 ./individuals ALL.chr1.250000.vcf 1 234376 250001 250000
8 ./individuals ALL.chr1.250000.vcf 1 78126 93751 250000
9 ./individuals ALL.chr1.250000.vcf 1 31251 46876 250000
10 ./individuals ALL.chr1.250000.vcf 1 203126 218751 250000
11 ./individuals ALL.chr1.250000.vcf 1 46876 62501 250000
12 ./individuals ALL.chr1.250000.vcf 1 218751 234376 250000
13 ./individuals ALL.chr1.250000.vcf 1 125001 140626 250000
14 ./individuals ALL.chr1.250000.vcf 1 93751 109376 250000
15 ./individuals ALL.chr1.250000.vcf 1 109376 125001 250000
16 ./individuals_merge 1 chr1n-1-15626.tar.gz chr1n-15626-31251.tar.gz chr1n-31251-46876.tar.gz chr1n-46876-62501.tar.gz chr1n-62501-78126.tar.gz chr1n-78126-93751.tar.gz chr1n-93751-109376.tar.gz chr1n-109376-125001.tar.gz chr1n-125001-140626.tar.gz chr1n-140626-156251.tar.gz chr1n-156251-171876.tar.gz chr1n-171876-187501.tar.gz chr1n-187501-203126.tar.gz chr1n-203126-218751.tar.gz chr1n-218751-234376.tar.gz chr1n-234376-250001.tar.gz
EOF
srun --multi-prog ./merge_cluster1.conf

