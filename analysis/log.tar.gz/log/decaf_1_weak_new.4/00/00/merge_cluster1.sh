#!/bin/bash
set -e

LAUNCH_DIR=`pwd`
echo "Job Launched in directory $LAUNCH_DIR"
source $DECAF_ENV_SOURCE


# copy the json file for the job into the directory
# where we are going to launch decaf
cp 1Kgenome.json $PEGASUS_SCRATCH_DIR/

cd $PEGASUS_SCRATCH_DIR
echo "Invoking decaf executable from directory `pwd`"
cat <<EOF > merge_cluster1.conf
0 ./individuals ALL.chr1.250000.vcf 1 1 5001 5000
1 ./individuals_merge 1 chr1n-1-5001.tar.gz
EOF
srun --multi-prog ./merge_cluster1.conf

