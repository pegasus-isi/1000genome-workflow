#!/bin/bash
set -e

LAUNCH_DIR=`pwd`
echo "Job Launched in directory $LAUNCH_DIR"
source $DECAF_ENV_SOURCE


# copy the json file for the job into the directory
# where we are going to launch decaf
cp 1Kgenome.json $PEGASUS_SCRATCH_DIR/

cd $PEGASUS_SCRATCH_DIR
echo "Invoking decaf executable from directory `pwd`"
cat <<EOF > merge_cluster1.conf
0 ./individuals ALL.chr1.250000.vcf 1 1 25001 250000
1 ./individuals ALL.chr1.250000.vcf 1 25001 50001 250000
2 ./individuals ALL.chr1.250000.vcf 1 225001 250001 250000
3 ./individuals ALL.chr1.250000.vcf 1 100001 125001 250000
4 ./individuals ALL.chr1.250000.vcf 1 125001 150001 250000
5 ./individuals ALL.chr1.250000.vcf 1 50001 75001 250000
6 ./individuals ALL.chr1.250000.vcf 1 75001 100001 250000
7 ./individuals ALL.chr1.250000.vcf 1 200001 225001 250000
8 ./individuals ALL.chr1.250000.vcf 1 150001 175001 250000
9 ./individuals ALL.chr1.250000.vcf 1 175001 200001 250000
10 ./individuals_merge 1 chr1n-1-25001.tar.gz chr1n-25001-50001.tar.gz chr1n-50001-75001.tar.gz chr1n-75001-100001.tar.gz chr1n-100001-125001.tar.gz chr1n-125001-150001.tar.gz chr1n-150001-175001.tar.gz chr1n-175001-200001.tar.gz chr1n-200001-225001.tar.gz chr1n-225001-250001.tar.gz
EOF
srun --multi-prog ./merge_cluster1.conf

