#!/bin/bash
set -e

LAUNCH_DIR=`pwd`
echo "Job Launched in directory $LAUNCH_DIR"
source $DECAF_ENV_SOURCE


# copy the json file for the job into the directory
# where we are going to launch decaf
cp 1Kgenome.json $PEGASUS_SCRATCH_DIR/

cd $PEGASUS_SCRATCH_DIR
echo "Invoking decaf executable from directory `pwd`"
cat <<EOF > merge_cluster1.conf
0 ./individuals ALL.chr1.250000.vcf 1 1 5001 20000
1 ./individuals ALL.chr1.250000.vcf 1 5001 10001 20000
2 ./individuals ALL.chr1.250000.vcf 1 10001 15001 20000
3 ./individuals ALL.chr1.250000.vcf 1 15001 20001 20000
4 ./individuals_merge 1 chr1n-1-5001.tar.gz chr1n-5001-10001.tar.gz chr1n-10001-15001.tar.gz chr1n-15001-20001.tar.gz
EOF
srun --multi-prog ./merge_cluster1.conf

