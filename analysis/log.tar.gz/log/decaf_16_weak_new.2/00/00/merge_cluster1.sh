#!/bin/bash
set -e

LAUNCH_DIR=`pwd`
echo "Job Launched in directory $LAUNCH_DIR"
source $DECAF_ENV_SOURCE


# copy the json file for the job into the directory
# where we are going to launch decaf
cp 1Kgenome.json $PEGASUS_SCRATCH_DIR/

cd $PEGASUS_SCRATCH_DIR
echo "Invoking decaf executable from directory `pwd`"
cat <<EOF > merge_cluster1.conf
0 ./individuals ALL.chr1.250000.vcf 1 1 5001 80000
1 ./individuals ALL.chr1.250000.vcf 1 55001 60001 80000
2 ./individuals ALL.chr1.250000.vcf 1 5001 10001 80000
3 ./individuals ALL.chr1.250000.vcf 1 60001 65001 80000
4 ./individuals ALL.chr1.250000.vcf 1 45001 50001 80000
5 ./individuals ALL.chr1.250000.vcf 1 50001 55001 80000
6 ./individuals ALL.chr1.250000.vcf 1 20001 25001 80000
7 ./individuals ALL.chr1.250000.vcf 1 75001 80001 80000
8 ./individuals ALL.chr1.250000.vcf 1 25001 30001 80000
9 ./individuals ALL.chr1.250000.vcf 1 10001 15001 80000
10 ./individuals ALL.chr1.250000.vcf 1 65001 70001 80000
11 ./individuals ALL.chr1.250000.vcf 1 15001 20001 80000
12 ./individuals ALL.chr1.250000.vcf 1 70001 75001 80000
13 ./individuals ALL.chr1.250000.vcf 1 40001 45001 80000
14 ./individuals ALL.chr1.250000.vcf 1 30001 35001 80000
15 ./individuals ALL.chr1.250000.vcf 1 35001 40001 80000
16 ./individuals_merge 1 chr1n-1-5001.tar.gz chr1n-5001-10001.tar.gz chr1n-10001-15001.tar.gz chr1n-15001-20001.tar.gz chr1n-20001-25001.tar.gz chr1n-25001-30001.tar.gz chr1n-30001-35001.tar.gz chr1n-35001-40001.tar.gz chr1n-40001-45001.tar.gz chr1n-45001-50001.tar.gz chr1n-50001-55001.tar.gz chr1n-55001-60001.tar.gz chr1n-60001-65001.tar.gz chr1n-65001-70001.tar.gz chr1n-70001-75001.tar.gz chr1n-75001-80001.tar.gz
EOF
srun --multi-prog ./merge_cluster1.conf

