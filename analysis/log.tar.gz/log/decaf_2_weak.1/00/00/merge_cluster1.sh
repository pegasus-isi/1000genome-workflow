#!/bin/bash
set -e

LAUNCH_DIR=`pwd`
echo "Job Launched in directory $LAUNCH_DIR"
source $DECAF_ENV_SOURCE


# copy the json file for the job into the directory
# where we are going to launch decaf
cp 1Kgenome.json $PEGASUS_SCRATCH_DIR/

cd $PEGASUS_SCRATCH_DIR
echo "Invoking decaf executable from directory `pwd`"
cat <<EOF > merge_cluster1.conf
0 ./individuals ALL.chr1.250000.vcf 1 1 15626 31250
1 ./individuals ALL.chr1.250000.vcf 1 15626 31251 31250
2 ./individuals_merge 1 chr1n-1-15626.tar.gz chr1n-15626-31251.tar.gz
EOF
srun --multi-prog ./merge_cluster1.conf

