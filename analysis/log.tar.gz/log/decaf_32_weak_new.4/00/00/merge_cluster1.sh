#!/bin/bash
set -e

LAUNCH_DIR=`pwd`
echo "Job Launched in directory $LAUNCH_DIR"
source $DECAF_ENV_SOURCE


# copy the json file for the job into the directory
# where we are going to launch decaf
cp 1Kgenome.json $PEGASUS_SCRATCH_DIR/

cd $PEGASUS_SCRATCH_DIR
echo "Invoking decaf executable from directory `pwd`"
cat <<EOF > merge_cluster1.conf
0 ./individuals ALL.chr1.250000.vcf 1 95001 100001 160000
1 ./individuals ALL.chr1.250000.vcf 1 1 5001 160000
2 ./individuals ALL.chr1.250000.vcf 1 110001 115001 160000
3 ./individuals ALL.chr1.250000.vcf 1 5001 10001 160000
4 ./individuals ALL.chr1.250000.vcf 1 115001 120001 160000
5 ./individuals ALL.chr1.250000.vcf 1 100001 105001 160000
6 ./individuals ALL.chr1.250000.vcf 1 105001 110001 160000
7 ./individuals ALL.chr1.250000.vcf 1 20001 25001 160000
8 ./individuals ALL.chr1.250000.vcf 1 130001 135001 160000
9 ./individuals ALL.chr1.250000.vcf 1 25001 30001 160000
10 ./individuals ALL.chr1.250000.vcf 1 135001 140001 160000
11 ./individuals ALL.chr1.250000.vcf 1 10001 15001 160000
12 ./individuals ALL.chr1.250000.vcf 1 120001 125001 160000
13 ./individuals ALL.chr1.250000.vcf 1 15001 20001 160000
14 ./individuals ALL.chr1.250000.vcf 1 125001 130001 160000
15 ./individuals ALL.chr1.250000.vcf 1 40001 45001 160000
16 ./individuals ALL.chr1.250000.vcf 1 30001 35001 160000
17 ./individuals ALL.chr1.250000.vcf 1 140001 145001 160000
18 ./individuals ALL.chr1.250000.vcf 1 35001 40001 160000
19 ./individuals ALL.chr1.250000.vcf 1 145001 150001 160000
20 ./individuals ALL.chr1.250000.vcf 1 150001 155001 160000
21 ./individuals ALL.chr1.250000.vcf 1 55001 60001 160000
22 ./individuals ALL.chr1.250000.vcf 1 60001 65001 160000
23 ./individuals ALL.chr1.250000.vcf 1 45001 50001 160000
24 ./individuals ALL.chr1.250000.vcf 1 155001 160001 160000
25 ./individuals ALL.chr1.250000.vcf 1 50001 55001 160000
26 ./individuals ALL.chr1.250000.vcf 1 75001 80001 160000
27 ./individuals ALL.chr1.250000.vcf 1 80001 85001 160000
28 ./individuals ALL.chr1.250000.vcf 1 65001 70001 160000
29 ./individuals ALL.chr1.250000.vcf 1 70001 75001 160000
30 ./individuals ALL.chr1.250000.vcf 1 85001 90001 160000
31 ./individuals ALL.chr1.250000.vcf 1 90001 95001 160000
32 ./individuals_merge 1 chr1n-1-5001.tar.gz chr1n-5001-10001.tar.gz chr1n-10001-15001.tar.gz chr1n-15001-20001.tar.gz chr1n-20001-25001.tar.gz chr1n-25001-30001.tar.gz chr1n-30001-35001.tar.gz chr1n-35001-40001.tar.gz chr1n-40001-45001.tar.gz chr1n-45001-50001.tar.gz chr1n-50001-55001.tar.gz chr1n-55001-60001.tar.gz chr1n-60001-65001.tar.gz chr1n-65001-70001.tar.gz chr1n-70001-75001.tar.gz chr1n-75001-80001.tar.gz chr1n-80001-85001.tar.gz chr1n-85001-90001.tar.gz chr1n-90001-95001.tar.gz chr1n-95001-100001.tar.gz chr1n-100001-105001.tar.gz chr1n-105001-110001.tar.gz chr1n-110001-115001.tar.gz chr1n-115001-120001.tar.gz chr1n-120001-125001.tar.gz chr1n-125001-130001.tar.gz chr1n-130001-135001.tar.gz chr1n-135001-140001.tar.gz chr1n-140001-145001.tar.gz chr1n-145001-150001.tar.gz chr1n-150001-155001.tar.gz chr1n-155001-160001.tar.gz
EOF
srun --multi-prog ./merge_cluster1.conf

